//
//  Groups.swift
//  GCD_Day14
//
//  Created by Dang Thai Son on 11/12/15.
//  Copyright © 2015 Dang Thai Son. All rights reserved.
//

import UIKit

class Groups: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let group = dispatch_group_create();
        
        dispatch_group_async(group,dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0)) {
            // block1
            NSLog("Block1");
            NSThread.sleepForTimeInterval(3.0)
            NSLog("Block1 End")
        }
        
        
        dispatch_group_async(group,dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0)) {
            // block2
            NSLog("Block2");
            NSThread.sleepForTimeInterval(5.0)
            NSLog("Block2 End");
        }
        
        dispatch_group_notify(group,dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0)){
            // block3
            NSLog("Block3");
        }
        
//        dispatch_group_wait(group,DISPATCH_TIME_FOREVER);
//        NSLog("Group Wait")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
