//
//  OperationQueue.swift
//  GCD_Day14
//
//  Created by Dang Thai Son on 11/12/15.
//  Copyright © 2015 Dang Thai Son. All rights reserved.
//

import UIKit

class OperationQueue: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let backgroundOperation = NSOperation()
        backgroundOperation.queuePriority = .Low
        backgroundOperation.qualityOfService = .Background
        
        
        let networkingOperation: NSOperation = NSOperation()
        let resizingOperation: NSOperation = NSOperation()
            resizingOperation.addDependency(networkingOperation)
        
        let operationQueue = NSOperationQueue.mainQueue()
        operationQueue.addOperations([networkingOperation, resizingOperation], waitUntilFinished: false)
        
        let operation = NSOperation()
        operation.completionBlock = {
            print("Completed")
        }
        
        operation.cancel()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
