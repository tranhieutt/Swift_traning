//
//  Async.swift
//  GCD_Day14
//
//  Created by Dang Thai Son on 11/12/15.
//  Copyright © 2015 Dang Thai Son. All rights reserved.
//

import UIKit

class Async: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let imageURL:String = "https://orig11.deviantart.net/2555/f/2014/217/6/1/gunnii_5_by_kimba-d7twlpg.png"
        
        
        // Sync
        
//        let url:NSURL = NSURL(string: imageURL)!
//        let imageData:NSData = NSData(contentsOfURL: url)!
//        self.imageView.image = UIImage(data: imageData)
        
        // Async
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0)) { () -> Void in
            let url:NSURL = NSURL(string: imageURL)!
            let imageData:NSData = NSData(contentsOfURL: url)!
            
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                self.imageView.image = UIImage(data: imageData)
            })
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
