//
//  ViewController.swift
//  GCD_Day14
//
//  Created by Dang Thai Son on 11/12/15.
//  Copyright © 2015 Dang Thai Son. All rights reserved.
//

import UIKit

class Queues: UIViewController {
    
    var string = "123" {
        willSet(newStr) {
            print("Change String")
            print(newStr)
        }

    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Default Queues
        let main = dispatch_get_main_queue()
        let userInteractive = dispatch_get_global_queue(QOS_CLASS_USER_INTERACTIVE, 0)
        let userInitiated = dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0)
        let utility =  dispatch_get_global_queue(QOS_CLASS_UTILITY, 0)
        let background = dispatch_get_global_queue(QOS_CLASS_BACKGROUND, 0)
        
//        string = "123"
        // Custom Queues
        let customQueue = dispatch_queue_create("CustomQueue", DISPATCH_QUEUE_CONCURRENT)
        let otherCustomQueue = dispatch_queue_create("OtherCustomQueue", DISPATCH_QUEUE_SERIAL)
        dispatch_async(main) { () -> Void in
            NSLog("Indside CustomQueue")
        }
        dispatch_async(userInteractive) { () -> Void in
            NSLog("Indside CustomQueue")
        }
        dispatch_async(userInitiated) { () -> Void in
            NSLog("Indside CustomQueue")
        }
        dispatch_async(utility) { () -> Void in
            NSLog("Indside CustomQueue")
        }
        dispatch_async(background) { () -> Void in
            NSLog("Indside CustomQueue")
        }


        // Use Custom Queues
        dispatch_async(customQueue) { () -> Void in
            NSLog("Indside CustomQueue")
        }
        
        dispatch_async(otherCustomQueue) { () -> Void in
            NSLog("Indside OtherCustomQueue")
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

