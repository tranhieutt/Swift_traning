//
//  Barrier_Async.swift
//  GCD_Day14
//
//  Created by Dang Thai Son on 11/12/15.
//  Copyright © 2015 Dang Thai Son. All rights reserved.
//

import UIKit

class Barrier_Async: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       let userInteractive = dispatch_get_global_queue(QOS_CLASS_USER_INTERACTIVE, 0)
        let customQueue = dispatch_queue_create("CustomQueue", DISPATCH_QUEUE_CONCURRENT)
        // Barrier Async
        for i in 1...10 {
            if (i == 5) {
//                sleep(1)
                // Use Custom Queue only
                dispatch_barrier_async(customQueue) { () -> Void in
                    NSLog("######################")
                    NSLog("## Writing File \(i)...##")
                    sleep(5)
                    NSLog("## Write Completed! ##")
                    NSLog("######################")
                }
            }

            dispatch_async(customQueue) { () -> Void in
                NSLog("Reading File \(i).")
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
